package com.example.binusezyfood.Items;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.binusezyfood.R;

public class ItemList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item);
    }
}