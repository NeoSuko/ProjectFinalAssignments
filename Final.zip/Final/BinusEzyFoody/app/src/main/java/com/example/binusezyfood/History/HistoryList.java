package com.example.binusezyfood.History;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.binusezyfood.R;

public class HistoryList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_history);
    }
}